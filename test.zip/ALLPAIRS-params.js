var config = {
	BOT_SLEEP_DELAY: ((1001)*80*(Math.random()*0.3+0.7)), // bot cycle delay (koef*sec)
	BOT_ON_FAIL_DELAY:((1001)*120*(Math.random()*0.3+0.7)), // bot repeat cycle delay if previous cycle failed  	//---POLONIEX
	POLONIEX_KEY: '',
	POLONIEX_SECRET: ''
};
 
module.exports = config;
